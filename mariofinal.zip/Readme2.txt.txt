This is my final release of my mario project. I have included the modified source code for
educational purposes.

File list:

Mario.exe           - Mario game
Marsrc55  *folder*  - Location of source code
Level Format.txt    - Text file containing information on the level format of the game.
Orientation.bmp     - Bitmap image showing in detail how a level is structured in worlds.pas
Readme2.txt         - The file your reading now.


To play the game, simply type Mario at the command prompt or double click mario.exe if
running windows.

The controls are:

CTRL+Arrow keys  - Run
Arrowkeys        - Walk
ALT              - Jump
CTRL+ALT         - Long Jump
Space bar        - Shoot fireballs
Lshift           - Scroll screen to the left
Rshift           - Scroll screen to the right.


Type "Mario.exe /?" (no quotes) for info on command line options for this game.


New levels copyright Spenser Whaley 2005-2006
Original game and levels copyright Mike Wiering (www.wieringsoftware.nl)

"Bush" graphic and "Fence" graphic used is some levels are copyright of Spenser Whaley.
This graphics are based on Super mario 3 bush and fence tiles, but I made them from scratch,
so Nintendo has no rights to them. :)

Orginal graphics in game copyright Mike Wiering (www.wieringsoftware.nl)

This game and its source code is freeware and is not to be sold under any condition.

